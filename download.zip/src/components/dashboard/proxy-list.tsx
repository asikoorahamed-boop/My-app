"use client"

import { Proxy } from "@/hooks/use-agent"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Globe, RefreshCw, CheckCircle2, XCircle } from "lucide-react"

interface ProxyListProps {
  proxies: Proxy[];
}

export function ProxyList({ proxies }: ProxyListProps) {
  return (
    <Card className="border-border bg-card/30">
      <CardHeader className="py-3 border-b border-border/50">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-accent" />
          <CardTitle className="text-sm font-headline uppercase tracking-widest">Global Proxy Scraper</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="max-h-[300px] overflow-y-auto terminal-scroll">
          {proxies.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground text-xs">
              <RefreshCw className="w-8 h-8 mx-auto mb-2 opacity-20" />
              Scan for proxies to begin...
            </div>
          ) : (
            <table className="w-full text-xs font-code">
              <thead className="sticky top-0 bg-secondary/80 backdrop-blur-sm text-muted-foreground uppercase text-[9px] tracking-tighter">
                <tr>
                  <th className="p-2 text-left">IP Address</th>
                  <th className="p-2 text-center">Status</th>
                  <th className="p-2 text-right">Latency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/30">
                {proxies.map((p, i) => (
                  <tr key={i} className="hover:bg-primary/5 transition-colors">
                    <td className="p-2 font-medium">{p.ip}:{p.port}</td>
                    <td className="p-2 text-center">
                      <div className="flex justify-center">
                        {p.status === 'checking' && <RefreshCw className="w-3 h-3 animate-spin text-muted-foreground" />}
                        {p.status === 'active' && <CheckCircle2 className="w-3 h-3 text-green-500" />}
                        {p.status === 'dead' && <XCircle className="w-3 h-3 text-red-500" />}
                      </div>
                    </td>
                    <td className="p-2 text-right text-muted-foreground">
                      {p.latency ? `${p.latency}ms` : '--'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
