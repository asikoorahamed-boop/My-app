"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card"
import { Shield, Play, Square, Settings, Smartphone, Target } from "lucide-react"

interface CampaignFormProps {
  url: string;
  setUrl: (url: string) => void;
  days: number;
  setDays: (days: number) => void;
  targetViews: number;
  setTargetViews: (views: number) => void;
  isRunning: boolean;
  persistenceMode: boolean;
  setPersistenceMode: (val: boolean) => void;
  onToggle: () => void;
}

export function CampaignForm({ 
  url, 
  setUrl, 
  days, 
  setDays, 
  targetViews,
  setTargetViews,
  isRunning, 
  persistenceMode, 
  setPersistenceMode, 
  onToggle 
}: CampaignFormProps) {
  return (
    <Card className="border-primary/20 bg-card/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            <CardTitle className="font-headline tracking-tight text-xl">Campaign Control Center</CardTitle>
          </div>
          <Settings className="w-4 h-4 text-muted-foreground animate-spin-slow" />
        </div>
        <CardDescription className="text-muted-foreground font-body">
          Define your target, duration, and traffic pacing.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="target-url" className="text-xs uppercase tracking-widest text-muted-foreground">Target URL</Label>
          <Input 
            id="target-url"
            placeholder="https://example.com"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            disabled={isRunning}
            className="bg-background/50 border-border focus:ring-primary/50"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="campaign-target" className="text-xs uppercase tracking-widest text-muted-foreground flex items-center gap-1">
              <Target className="w-3 h-3" /> Total Target (Views)
            </Label>
            <Input 
              id="campaign-target"
              type="number"
              min={100}
              step={100}
              value={targetViews}
              onChange={(e) => setTargetViews(parseInt(e.target.value))}
              disabled={isRunning}
              className="bg-background/50 border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration" className="text-xs uppercase tracking-widest text-muted-foreground">Deployment Duration (Days)</Label>
            <Input 
              id="duration"
              type="number"
              min={1}
              max={30}
              value={days}
              onChange={(e) => setDays(parseInt(e.target.value))}
              disabled={isRunning}
              className="bg-background/50 border-border"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg bg-black/20 border border-border/50">
            <div className="flex items-center gap-3">
              <Smartphone className={`w-4 h-4 ${persistenceMode ? 'text-primary' : 'text-muted-foreground'}`} />
              <div>
                <Label className="text-sm font-medium">Foreground Persistence</Label>
                <p className="text-[10px] text-muted-foreground">Simulate long-term background service</p>
              </div>
            </div>
            <Switch 
              checked={persistenceMode} 
              onCheckedChange={setPersistenceMode} 
              disabled={isRunning}
            />
          </div>

          <div className="flex gap-1 overflow-x-auto pb-2 scrollbar-hide">
            {[1, 7, 14, 30].map(d => (
              <Button 
                key={d}
                variant={days === d ? "default" : "outline"}
                size="sm"
                onClick={() => setDays(d)}
                disabled={isRunning}
                className="h-8 text-xs px-4 flex-shrink-0"
              >
                {d} Days
              </Button>
            ))}
          </div>
        </div>

        <Button 
          onClick={onToggle}
          variant={isRunning ? "destructive" : "default"}
          className={`w-full font-headline uppercase tracking-tighter text-lg py-6 shadow-xl transition-all ${isRunning ? '' : 'active-glow'}`}
        >
          {isRunning ? (
            <><Square className="w-5 h-5 mr-2 fill-current" /> Terminate Agent</>
          ) : (
            <><Play className="w-5 h-5 mr-2 fill-current" /> Deploy Agent</>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
