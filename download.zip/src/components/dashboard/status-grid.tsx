"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Users, Trash2, Clock, Globe } from "lucide-react"

interface StatusGridProps {
  stats: {
    visits: number;
    wipes: number;
    uptime: string;
    activeProxy: string;
  };
  isRunning: boolean;
}

export function StatusGrid({ stats, isRunning }: StatusGridProps) {
  const items = [
    { 
      label: 'Total Visits', 
      value: stats.visits, 
      icon: Users, 
      color: 'text-primary' 
    },
    { 
      label: 'Context Wipes', 
      value: stats.wipes, 
      icon: Trash2, 
      color: 'text-destructive' 
    },
    { 
      label: 'Session Uptime', 
      value: stats.uptime, 
      icon: Clock, 
      color: 'text-accent' 
    },
    { 
      label: 'Active Proxy', 
      value: stats.activeProxy, 
      icon: Globe, 
      color: 'text-muted-foreground' 
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {items.map((item, i) => (
        <Card key={i} className="border-border/50 bg-card/30">
          <CardContent className="p-4 flex flex-col items-center text-center">
            <item.icon className={`w-5 h-5 mb-2 ${item.color} ${isRunning && i === 2 ? 'animate-pulse' : ''}`} />
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">{item.label}</p>
            <p className="font-headline font-bold text-lg tracking-tight">{item.value}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
