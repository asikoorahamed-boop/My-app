"use client"

import { LogEntry } from "@/hooks/use-agent"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Terminal as TerminalIcon, Cpu } from "lucide-react"

interface ActivityTerminalProps {
  logs: LogEntry[];
}

export function ActivityTerminal({ logs }: ActivityTerminalProps) {
  return (
    <Card className="border-border bg-black/40 h-full flex flex-col">
      <CardHeader className="py-3 border-b border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TerminalIcon className="w-4 h-4 text-muted-foreground" />
            <CardTitle className="text-sm font-headline uppercase tracking-widest">Live Activity Log</CardTitle>
          </div>
          <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
             <span className="text-[10px] text-muted-foreground font-code">SERVICE_UP</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden p-0">
        <div className="h-[400px] overflow-y-auto p-4 font-code text-xs space-y-2 terminal-scroll">
          {logs.length === 0 && (
            <div className="text-muted-foreground opacity-50 italic">
              [SYSTEM] Waiting for process initiation...
            </div>
          )}
          {logs.map((log) => (
            <div key={log.id} className="flex gap-2 animate-in fade-in slide-in-from-left-2 duration-300">
              <span className="text-muted-foreground shrink-0">
                [{log.timestamp.toLocaleTimeString([], { hour12: false })}]
              </span>
              <span className={
                log.type === 'success' ? 'text-green-400' :
                log.type === 'error' ? 'text-red-400' :
                log.type === 'warning' ? 'text-yellow-400' :
                log.type === 'agent' ? 'text-primary' :
                'text-foreground/80'
              }>
                {log.type === 'agent' ? '>> ' : ''}{log.message}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
