"use client"

import { useState, useEffect, useCallback, useRef } from 'react';
import { aiHumanBehaviorScriptGeneration } from '@/ai/flows/ai-human-behavior-script-generation';
import { fetchPublicProxies, ProxyData } from '@/services/proxy-service';

export type LogEntry = {
  id: string;
  timestamp: Date;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'agent';
};

export type Proxy = {
  ip: string;
  port: string;
  status: 'checking' | 'active' | 'dead';
  latency?: number;
  isp?: string;
};

const USER_AGENTS = [
  'Mozilla/5.0 (Linux; Android 10; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
];

const RESOLUTIONS = [
  { w: 1920, h: 1080 },
  { w: 1440, h: 900 },
  { w: 1366, h: 768 },
  { w: 1536, h: 864 },
  { w: 375, h: 667 }, 
  { w: 390, h: 844 }, 
  { w: 412, h: 915 }, 
];

const DPRS = [1, 1.25, 1.5, 2, 3];

export function useAgent() {
  const [isRunning, setIsRunning] = useState(false);
  const [persistenceMode, setPersistenceMode] = useState(false);
  const [url, setUrl] = useState('');
  const [days, setDays] = useState(7);
  const [targetViews, setTargetViews] = useState(1000);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [proxies, setProxies] = useState<Proxy[]>([]);
  const [stats, setStats] = useState({
    visits: 0,
    wipes: 0,
    uptime: '00:00:00',
    activeProxy: 'None',
  });

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const isRunningRef = useRef(false);
  
  const visitsTodayRef = useRef(0);
  const lastDayIndexRef = useRef(-1);

  const addLog = useCallback((message: string, type: LogEntry['type'] = 'info') => {
    setLogs(prev => [
      {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date(),
        message,
        type
      },
      ...prev.slice(0, 49)
    ]);
  }, []);

  const scrapeProxies = useCallback(async () => {
    addLog('Scraping elite high-anonymity nodes...', 'info');
    try {
      const freshProxies = await fetchPublicProxies();
      const formatted: Proxy[] = freshProxies.map(p => ({
        ip: p.ip,
        port: p.port,
        status: 'active',
        latency: p.latency,
        isp: p.isp
      }));
      setProxies(formatted);
      addLog(`Found ${formatted.length} Elite Residential/Transparent nodes. Datacenters filtered.`, 'success');
      return formatted;
    } catch (e) {
      addLog('Primary proxy layer down. Rotating secure fallbacks.', 'warning');
      return [];
    }
  }, [addLog]);

  const calculateDailyTarget = useCallback((currentDay: number, totalDays: number, totalTarget: number) => {
    // Traffic Pacing Algorithm: Quadratic Weighting (d+1)^1.5
    // This ensures low week 1 and heavy scaling towards the end
    let sumWeights = 0;
    for (let i = 1; i <= totalDays; i++) {
      sumWeights += Math.pow(i, 1.5);
    }
    
    const weightCurrent = Math.pow(currentDay + 1, 1.5);
    const dailyTarget = Math.floor((weightCurrent / sumWeights) * totalTarget);
    
    // Ensure at least some activity if target is high
    return Math.max(dailyTarget, 5);
  }, []);

  const runCycle = useCallback(async () => {
    if (!isRunningRef.current) return;

    const now = Date.now();
    const elapsed = now - (startTimeRef.current || now);
    const currentDayIndex = Math.floor(elapsed / 86400000);

    if (currentDayIndex !== lastDayIndexRef.current) {
      lastDayIndexRef.current = currentDayIndex;
      visitsTodayRef.current = 0;
      addLog(`[PACING] Day ${currentDayIndex + 1} of ${days} started. Calculating distribution.`, 'info');
    }

    if (currentDayIndex >= days) {
      addLog(`[SYSTEM] Full ${days}-day campaign target reached. Shutting down kernel.`, 'warning');
      setIsRunning(false);
      isRunningRef.current = false;
      return;
    }

    const currentDayCap = calculateDailyTarget(currentDayIndex, days, targetViews);

    if (visitsTodayRef.current >= currentDayCap) {
      addLog(`[QUOTA] Daily pacing target (${currentDayCap} visits) reached for Day ${currentDayIndex + 1}.`, 'warning');
      addLog('Entering hibernation until next 24h cycle to preserve traffic rhythm...', 'info');
      const msUntilNextDay = 86400000 - (elapsed % 86400000);
      timerRef.current = setTimeout(runCycle, msUntilNextDay + 1000);
      return;
    }

    // 1. Initiate stealth handshake
    addLog(`Initiating stealth cycle for ${url} (Progress: ${visitsTodayRef.current + 1}/${currentDayCap} for today)`, 'agent');
    
    let currentProxies = proxies;
    if (currentProxies.length === 0) {
      currentProxies = await scrapeProxies();
    }
    
    const active = currentProxies.filter(p => p.status === 'active');
    if (active.length === 0) {
      addLog('Exit nodes exhausted. Refreshing elite list...', 'error');
      await scrapeProxies();
      timerRef.current = setTimeout(runCycle, 5000);
      return;
    }

    const proxy = active[Math.floor(Math.random() * active.length)];
    setStats(s => ({ ...s, activeProxy: `${proxy.ip}:${proxy.port}` }));
    addLog(`Tunneling via Elite Node: ${proxy.ip} | Masquerading as ${proxy.isp || 'Residential'}`, 'success');

    // 2. Identity & Canvas Masquerade
    const ua = USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
    const res = RESOLUTIONS[Math.floor(Math.random() * RESOLUTIONS.length)];
    const dpr = DPRS[Math.floor(Math.random() * DPRS.length)];
    
    addLog(`Rotating fingerprints: User-Agent set to ${ua.substring(0, 30)}...`, 'info');
    addLog(`Canvas Masquerade: ${res.w}x${res.h} @ ${dpr}x. Anti-fingerprinting protocol active.`, 'success');

    // 3. Referer Spoofing
    addLog(`Header Injection: X-Referer forced to internal origin ${url}`, 'success');

    // 4. GenAI Interaction
    try {
      addLog('Synthesizing high-conversion behavioral pattern...', 'info');
      await aiHumanBehaviorScriptGeneration({
        websiteDescription: `Navigating ${url}. Target: ad links/buttons. Behavioral entropy: High.`,
        minInteractionSeconds: 30,
        maxInteractionSeconds: 90
      });
      addLog('Stealth payload delivered. Conversion interaction logged.', 'success');
      
      const dwellTime = Math.floor(Math.random() * 20000) + 10000;
      await new Promise(r => setTimeout(r, dwellTime));
    } catch (e) {
      addLog('Behavioral engine error. Reverting to Pattern-X bypass.', 'warning');
      await new Promise(r => setTimeout(r, 10000));
    }

    // 5. Persistence & Wipe
    addLog('Scrubbing session metadata: Cookies, Cache, and IndexedDB purged.', 'warning');
    visitsTodayRef.current += 1;
    setStats(s => ({ ...s, visits: s.visits + 1, wipes: s.wipes + 1 }));
    addLog('Identity neutralized. Tunnel collapsed.', 'success');

    // 6. Intelligent Traffic Pacing Cooldown
    // Calculate average spacing needed for remaining daily cap
    const msInDay = 86400000;
    const elapsedToday = elapsed % msInDay;
    const remainingTimeToday = msInDay - elapsedToday;
    const remainingVisits = Math.max(currentDayCap - visitsTodayRef.current, 1);
    
    const avgSpacing = remainingTimeToday / remainingVisits;
    const jitter = 0.8 + (Math.random() * 0.4); // 80% to 120% variation
    const dynamicCooldown = Math.max(Math.floor(avgSpacing * jitter), 120000); // Floor at 2 mins
    
    addLog(`Pacing Strategy: Idle for ${Math.floor(dynamicCooldown/1000)}s to maintain natural traffic density.`, 'info');
    
    if (isRunningRef.current) {
      timerRef.current = setTimeout(runCycle, dynamicCooldown);
    }
  }, [url, proxies, addLog, scrapeProxies, days, targetViews, calculateDailyTarget]);

  const toggleAgent = () => {
    if (!isRunning) {
      if (!url) {
        addLog('Critical Error: Target URL must be defined.', 'error');
        return;
      }
      setIsRunning(true);
      isRunningRef.current = true;
      startTimeRef.current = Date.now();
      visitsTodayRef.current = 0;
      lastDayIndexRef.current = 0;
      addLog('ShadowAgent Kernel Online. Traffic Pacing Protocol V4 engaged.', 'success');
      addLog(`Pacing Strategy: Distributing ${targetViews} views over ${days} days. Week 1 ramp-up enabled.`, 'info');
      
      scrapeProxies().then(() => {
        if (isRunningRef.current) runCycle();
      });
    } else {
      setIsRunning(false);
      isRunningRef.current = false;
      if (timerRef.current) clearTimeout(timerRef.current);
      addLog('Force termination. Fingerprints purged from kernel.', 'warning');
      setStats(s => ({ ...s, activeProxy: 'None' }));
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning) {
      interval = setInterval(() => {
        const diff = Date.now() - (startTimeRef.current || 0);
        const hrs = Math.floor(diff / 3600000).toString().padStart(2, '0');
        const mins = Math.floor((diff % 3600000) / 60000).toString().padStart(2, '0');
        const secs = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
        setStats(s => ({ ...s, uptime: `${hrs}:${mins}:${secs}` }));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  return {
    isRunning,
    persistenceMode,
    setPersistenceMode,
    url,
    setUrl,
    days,
    setDays,
    targetViews,
    setTargetViews,
    logs,
    proxies,
    stats,
    toggleAgent
  };
}
