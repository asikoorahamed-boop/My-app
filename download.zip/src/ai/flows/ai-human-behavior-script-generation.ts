'use server';
/**
 * @fileOverview This file defines a Genkit flow for generating JavaScript scripts that simulate human browsing behavior.
 *
 * - aiHumanBehaviorScriptGeneration - A function that generates a JavaScript script for human-like web interactions.
 * - AiHumanBehaviorScriptGenerationInput - The input type for the aiHumanBehaviorScriptGeneration function.
 * - AiHumanBehaviorScriptGenerationOutput - The return type for the aiHumanBehaviorScriptGeneration function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Input schema for the human behavior script generation flow.
const AiHumanBehaviorScriptGenerationInputSchema = z.object({
  websiteDescription: z
    .string()
    .describe('A brief description of the website or the type of content it contains, to help tailor interaction scripts.'),
  minInteractionSeconds: z
    .number()
    .int()
    .min(1)
    .describe('The minimum number of seconds the generated script should simulate interaction for.'),
  maxInteractionSeconds: z
    .number()
    .int()
    .min(1)
    .describe('The maximum number of seconds the generated script should simulate interaction for.'),
});
export type AiHumanBehaviorScriptGenerationInput = z.infer<typeof AiHumanBehaviorScriptGenerationInputSchema>;

// Output schema for the human behavior script generation flow.
const AiHumanBehaviorScriptGenerationOutputSchema = z.object({
  javascriptCode: z
    .string()
    .describe('The generated JavaScript code that simulates human-like browsing behavior.'),
});
export type AiHumanBehaviorScriptGenerationOutput = z.infer<typeof AiHumanBehaviorScriptGenerationOutputSchema>;

// Wrapper function to call the Genkit flow.
export async function aiHumanBehaviorScriptGeneration(
  input: AiHumanBehaviorScriptGenerationInput
): Promise<AiHumanBehaviorScriptGenerationOutput> {
  return aiHumanBehaviorScriptGenerationFlow(input);
}

// Define the prompt for generating the human behavior script.
const generateBehaviorScriptPrompt = ai.definePrompt({
  name: 'generateBehaviorScriptPrompt',
  input: { schema: AiHumanBehaviorScriptGenerationInputSchema },
  output: { schema: AiHumanBehaviorScriptGenerationOutputSchema },
  prompt: `You are an expert in simulating human web browsing behavior for high-conversion engagement. Your task is to generate a JavaScript script that can be injected into a WebView to mimic human interaction flawlessly.

The script should operate for a random duration between {{minInteractionSeconds}} and {{maxInteractionSeconds}} seconds on the site: "{{websiteDescription}}".

The generated script MUST:
1.  Define robust helper functions for smooth, variable-speed scrolling and random coordinate generation.
2.  Implement a main routine that:
    a.  Starts with a short initial "read time" delay (3-5 seconds).
    b.  Performs a series of erratic, non-linear scrolls (up and down) to simulate content consumption.
    c.  CRITICAL STEP: Scan the DOM for high-priority interaction elements. These include direct links, call-to-action buttons, or elements matching common ad-network selector patterns (e.g., direct link buttons).
    d.  Once an target element is found:
        i.  Scroll it into the viewport naturally.
        ii. Wait 2-4 seconds (as if deciding to click).
        iii. Move a virtual cursor (or simulate a touch event) with a slight offset from the center to avoid robotic accuracy.
        iv. Trigger a click/tap event.
    e.  If multiple elements are found, choose one randomly to ensure varied paths across sessions.
3.  Include variable "micro-pauses" (500ms to 2000ms) between every simulated movement.

The output MUST be valid, self-contained JavaScript and ONLY output the JavaScript code. Do not include markdown formatting or comments outside the script.

Example pattern:
async function performTargetedAction() {
    const targets = Array.from(document.querySelectorAll('a, button')).filter(el => {
        const text = el.innerText.toLowerCase();
        return text.includes('click') || text.includes('view') || el.href?.includes('ad');
    });
    if (targets.length > 0) {
        const target = targets[Math.floor(Math.random() * targets.length)];
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await new Promise(r => setTimeout(r, 3000));
        target.click();
    }
}
`,
});

// Define the Genkit flow for human behavior script generation.
const aiHumanBehaviorScriptGenerationFlow = ai.defineFlow(
  {
    name: 'aiHumanBehaviorScriptGenerationFlow',
    inputSchema: AiHumanBehaviorScriptGenerationInputSchema,
    outputSchema: AiHumanBehaviorScriptGenerationOutputSchema,
  },
  async (input) => {
    const { output } = await generateBehaviorScriptPrompt(input);
    if (!output) {
      throw new Error('Failed to generate human behavior script.');
    }
    return output;
  }
);
