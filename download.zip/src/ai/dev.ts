import { config } from 'dotenv';
config();

import '@/ai/flows/ai-human-behavior-script-generation.ts';