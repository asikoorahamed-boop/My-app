"use client"

import { useAgent } from "@/hooks/use-agent"
import { CampaignForm } from "@/components/dashboard/campaign-form"
import { StatusGrid } from "@/components/dashboard/status-grid"
import { ActivityTerminal } from "@/components/dashboard/activity-terminal"
import { ProxyList } from "@/components/dashboard/proxy-list"
import { ShieldAlert, Zap, Cpu, Bell } from "lucide-react"

export default function Home() {
  const { 
    isRunning, 
    persistenceMode, 
    setPersistenceMode, 
    url, 
    setUrl, 
    days, 
    setDays, 
    targetViews,
    setTargetViews,
    logs, 
    proxies, 
    stats, 
    toggleAgent 
  } = useAgent();

  return (
    <div className="min-h-screen bg-[#111217] text-foreground selection:bg-primary/30">
      {/* Background Decor */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent/20 blur-[120px] rounded-full" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <header className="flex flex-col md:flex-row items-center justify-between mb-12 gap-6">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl bg-primary/10 border border-primary/20 ${isRunning ? 'active-glow' : ''}`}>
              <ShieldAlert className={`w-8 h-8 text-primary ${isRunning ? 'animate-pulse' : ''}`} />
            </div>
            <div>
              <h1 className="text-4xl font-headline font-bold tracking-tighter uppercase leading-none">Shadow<span className="text-primary">Agent</span></h1>
              <p className="text-xs text-muted-foreground font-code mt-1 tracking-widest flex items-center gap-2">
                <Zap className="w-3 h-3 text-accent" /> STEALTH_BROWSING_PROTOCOL_V4.0
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-right">
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-body">Agent Status</p>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]' : 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]'}`} />
                <span className="font-headline font-semibold text-sm uppercase">
                  {isRunning ? 'Operational' : 'Idle'}
                </span>
              </div>
            </div>
            <div className="h-10 w-px bg-border/50 hidden md:block" />
            <div className="hidden lg:flex items-center gap-3">
              <Cpu className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-body">Processing Unit</p>
                <p className="text-xs font-code uppercase">Pacing_Kernel_V4</p>
              </div>
            </div>
          </div>
        </header>

        {/* Persistent Notification Simulation */}
        {isRunning && persistenceMode && (
          <div className="mb-6 animate-in slide-in-from-top-4 duration-500">
            <div className="bg-primary/20 border border-primary/30 rounded-lg p-3 flex items-center justify-between backdrop-blur-md">
              <div className="flex items-center gap-3">
                <div className="bg-primary p-1.5 rounded-full">
                  <Bell className="w-3 h-3 text-primary-foreground" />
                </div>
                <div className="text-xs">
                  <p className="font-bold uppercase tracking-tight">Active Foreground Service</p>
                  <p className="text-muted-foreground">ShadowAgent is running in stealth background mode. Persistent notification enabled.</p>
                </div>
              </div>
              <div className="px-2 py-1 bg-primary/20 rounded text-[9px] font-code uppercase border border-primary/30">
                CAMPAIGN: {days}D | TARGET: {targetViews}
              </div>
            </div>
          </div>
        )}

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column - Controls & Stats */}
          <div className="lg:col-span-5 space-y-6">
            <CampaignForm 
              url={url} 
              setUrl={setUrl} 
              days={days} 
              setDays={setDays} 
              targetViews={targetViews}
              setTargetViews={setTargetViews}
              isRunning={isRunning} 
              persistenceMode={persistenceMode}
              setPersistenceMode={setPersistenceMode}
              onToggle={toggleAgent} 
            />
            
            <StatusGrid stats={stats} isRunning={isRunning} />

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-6 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Zap className="w-16 h-16 text-primary" />
              </div>
              <h3 className="font-headline font-bold text-lg mb-2 flex items-center gap-2">
                Smart Traffic Pacing
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Utilizing non-linear growth algorithms to simulate natural audience expansion. Traffic is automatically distributed across the deployment period with randomized idle intervals to defeat advanced fraud detection.
              </p>
              <div className="mt-4 flex gap-2">
                <span className="text-[9px] bg-primary/20 text-primary-foreground px-2 py-1 rounded-md font-code">TRAFFIC_RAMP</span>
                <span className="text-[9px] bg-accent/20 text-accent-foreground px-2 py-1 rounded-md font-code">SMART_COOLDOWN</span>
              </div>
            </div>
          </div>

          {/* Right Column - Logs & Proxies */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <div className="flex-1 min-h-[450px]">
              <ActivityTerminal logs={logs} />
            </div>
            <div className="h-auto">
              <ProxyList proxies={proxies} />
            </div>
          </div>

        </div>

        {/* Footer */}
        <footer className="mt-12 pt-6 border-t border-border/50 text-center">
          <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-body">
            ShadowAgent &copy; 2024 • Secured by Smart Traffic Pacing Protocol • Unauthorized replication strictly prohibited
          </p>
        </footer>
      </div>
    </div>
  );
}
